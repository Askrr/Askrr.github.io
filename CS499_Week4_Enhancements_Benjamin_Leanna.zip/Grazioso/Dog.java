// Enhancements added March 24th 2024
// Benjamin Leanna 499 - CS Capstone
// SNHU
// 2024-03-24 additional attributes added, setter methods to enhance validation logic for input data 
// and a method to calculate the dogs age. 

import java.util.Calendar;

public class Dog extends RescueAnimal {

    // Instance variable
    private String breed;
    // adding in more for enhancement
    private boolean vaccinated;
    private String temperament;
    private String specialNeeds;

    // Constructor redone for enhancement
    // Adding in more additional parameters and calling of superclass constructor
    // Will comment out original code to keep for reference
    //public Dog(String name, String breed, String gender, String age,
    //String weight, String acquisitionDate, String acquisitionCountry,
	//String trainingStatus, boolean reserved, String inServiceCountry) {
    //    setName(name);
    //    setBreed(breed);
    //    setGender(gender);
    //    setAge(age);
    //    setWeight(weight);
    //    setAcquisitionDate(acquisitionDate);
    //    setAcquisitionLocation(acquisitionCountry);
    //    setTrainingStatus(trainingStatus);
    //    setReserved(reserved);
    //    setInServiceCountry(inServiceCountry);
    //
    //}
    public Dog(String name, String breed, String gender, String age, String weight,
               String acquisitionDate, String acquisitionCountry, String trainingStatus,
               boolean reserved, String inServiceCountry, boolean vaccinated,
               String temperament, String specialNeeds) {
        // Call superclass constructor
        super(name, gender, age, weight, acquisitionDate, acquisitionCountry,
                trainingStatus, reserved, inServiceCountry);
        setBreed(breed);
        this.vaccinated = vaccinated;
        this.temperament = temperament;
        this.specialNeeds = specialNeeds;
    }

    // Accessor Method
    public String getBreed() {
        return breed;
    }

    // Mutator Method
    public void setBreed(String dogBreed) {
        breed = dogBreed;
    }

    // Getter and setter methods for new attributes
    public boolean isVaccinated() {
        return vaccinated;
    }

    public void setVaccinated(boolean vaccinated) {
        this.vaccinated = vaccinated;
    }

    public String getTemperament() {
        return temperament;
    }

    public void setTemperament(String temperament) {
        this.temperament = temperament;
    }

    public String getSpecialNeeds() {
        return specialNeeds;
    }

    public void setSpecialNeeds(String specialNeeds) {
        this.specialNeeds = specialNeeds;
    }

    // Refactored method to calculate dog's age based on birth year
    public int calculateAge(int birthYear) {
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        return currentYear - birthYear;
    }
}
