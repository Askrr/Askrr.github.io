// Enhancements added March 24th 2024
// Benjamin Leanna 499 - CS Capstone
// SNHU
// Enhancements added 2024-03-24 to add new attribues to provide additional information on each anmial
// modified the constructor to include the new parameters for the new attribues
// implemented getter and setter methods for new attribues (allows access and modifications)
// added in the logger object to enable logging of events or errors in the class
// added the logEvent method to facilitate logging

import java.lang.String;

public class RescueAnimal {

    // Instance variables
    private String name;
    private String animalType;
    private String gender;
    private String age;
    private String weight;
    private String acquisitionDate;
    private String acquisitionCountry;
	private String trainingStatus;
    private boolean reserved;
	private String inServiceCountry;
	// enhancement added of new variables
    private boolean vaccinated;
    private String temperament;
    private String specialNeeds;

    // enhancement for logging events or errors
    private static final Logger LOGGER = Logger.getLogger(RescueAnimal.class.getName());

    // Empty Constructor
    public RescueAnimal() {
    }

    // Constructor with enhancements
    public RescueAnimal(String name, String gender, String age, String weight, 
                        String acquisitionDate, String acquisitionCountry, 
                        String trainingStatus, boolean reserved, String inServiceCountry,
                        boolean vaccinated, String temperament, String specialNeeds) {
        setName(name);
        setGender(gender);
        setAge(age);
        setWeight(weight);
        setAcquisitionDate(acquisitionDate);
        setAcquisitionCountry(acquisitionCountry);
        setTrainingStatus(trainingStatus);
        setReserved(reserved);
        setInServiceCountry(inServiceCountry);
        setVaccinated(vaccinated);
        setTemperament(temperament);
        setSpecialNeeds(specialNeeds);
    }


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAnimalType() {
		return animalType;
	}


	public void setAnimalType(String animalType) {
		this.animalType = animalType;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getAge() {
		return age;
	}


	public void setAge(String age) {
		this.age = age;
	}


	public String getWeight() {
		return weight;
	}


	public void setWeight(String weight) {
		this.weight = weight;
	}


	public String getAcquisitionDate() {
		return acquisitionDate;
	}


	public void setAcquisitionDate(String acquisitionDate) {
		this.acquisitionDate = acquisitionDate;
	}


	public String getAcquisitionLocation() {
		return acquisitionCountry;
	}

	public void setAcquisitionLocation(String acquisitionCountry) {
		this.acquisitionCountry = acquisitionCountry;
	}


	public boolean getReserved() {
		return reserved;
	}


	public void setReserved(boolean reserved) {
		this.reserved = reserved;
	}


	public String getInServiceLocation() {
		return inServiceCountry;
	}


	public void setInServiceCountry(String inServiceCountry) {
		this.inServiceCountry = inServiceCountry;
	}

	public String getTrainingStatus() {
		return trainingStatus;
	}


	public void setTrainingStatus(String trainingStatus) {
		this.trainingStatus = trainingStatus;
	}

    // Enhancement of Additional Getter and Setter methods for new variables
    public boolean isVaccinated() {
        return vaccinated;
    }

    public void setVaccinated(boolean vaccinated) {
        this.vaccinated = vaccinated;
    }

    public String getTemperament() {
        return temperament;
    }

    public void setTemperament(String temperament) {
        this.temperament = temperament;
    }

    public String getSpecialNeeds() {
        return specialNeeds;
    }

    public void setSpecialNeeds(String specialNeeds) {
        this.specialNeeds = specialNeeds;
    }

    // Method to log events or errors
    public void logEvent(String message) {
        LOGGER.log(Level.INFO, message);
    }
}
