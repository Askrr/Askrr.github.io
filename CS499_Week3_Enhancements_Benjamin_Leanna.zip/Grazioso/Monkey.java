// Enhancements added March 24th 2024
// Benjamin Leanna 499 - CS Capstone
// SNHU
// Enhancements added 2024-03-24 to add new attribues
// modified the constructor to include new parameters and call the superclass
// and implemented getter and setter methods for the new attribues.

public class Monkey extends RescueAnimal {
    //variables
    private String breed;
    private String height;
    private String tailLength;
    private String bodyLength;
    //adding additional variables
    private boolean vaccinated;
    private String temperament;
    private String specialNeeds;

    public final static String[] MONKEY_BREEDS = {
        "Capuchin",
        "Tamarin",
        "Macaque",
        "Marmoset",
        "Squirrel monkey",
        "Guenon"
    };
    //constructor
    // enhancement added for additional variables and superclass constructor. will keep original code commented
    // public Monkey(
    //     String name, String breed, String gender, String age,
    //     String weight, String height, String bodyLength, String tailLength,
    //     String acquisitionDate, String acquisitionCountry,
    //     String trainingStatus, boolean reserved, String inServiceCountry
    // ) {
    //     setName(name);
    //     setBreed(breed);
    //     setGender(gender);
    //     setAge(age);
    //     setWeight(weight);
    //     setHeight(height);
    //     setBodyLength(bodyLength);
    //     setTailLength(tailLength);
    //     setAcquisitionDate(acquisitionDate);
    //     setAcquisitionLocation(acquisitionCountry);
    //     setTrainingStatus(trainingStatus);
    //     setReserved(reserved);
    //     setInServiceCountry(inServiceCountry);
    // }
    public Monkey(
        String name, String breed, String gender, String age,
        String weight, String height, String bodyLength, String tailLength,
        String acquisitionDate, String acquisitionCountry,
        String trainingStatus, boolean reserved, String inServiceCountry,
        boolean vaccinated, String temperament, String specialNeeds
    ) {
        // Call superclass constructor
        super(name, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved, inServiceCountry);
        // Set new attributes
        setBreed(breed);
        setHeight(height);
        setBodyLength(bodyLength);
        setTailLength(tailLength);
        // Set additional attributes
        setVaccinated(vaccinated);
        setTemperament(temperament);
        setSpecialNeeds(specialNeeds);
    }

    //accessor
    public String getBreed() {
        return breed;
    }
    public String getHeight() {
        return height;
    }
    public String getTailLength() {
        return tailLength;
    }
    public String getBodyLength() {
        return bodyLength;
    }
    //adding in more accessors for enhancement
    public boolean isVaccinated() {
        return vaccinated;
    }

    public String getTemperament() {
        return temperament;
    }

    public String getSpecialNeeds() {
        return specialNeeds;
    }
    //mutator
    public void setBreed(String monkeyBreed) {
        breed = monkeyBreed;
    }
    public void setHeight(String monkeyHeight) {
        height = monkeyHeight;
    }
    public void setTailLength(String monkeyTailLength) {
        tailLength = monkeyTailLength;
    }
    public void setBodyLength(String monkeyBodyLength) {
        bodyLength = monkeyBodyLength;
    }
    //adding in more mutators for enhancement

    public void setVaccinated(boolean monkeyVaccinated) {
        vaccinated = monkeyVaccinated;
    }

    public void setTemperament(String monkeyTemperament) {
        temperament = monkeyTemperament;
    }

    public void setSpecialNeeds(String monkeySpecialNeeds) {
        specialNeeds = monkeySpecialNeeds;
    }
}
